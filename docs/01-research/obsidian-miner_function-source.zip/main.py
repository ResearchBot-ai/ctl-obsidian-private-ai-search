import functions_framework
import requests
import json
import time
import re
import os
import random
from datetime import datetime
from google.cloud import storage

# --- CONFIGURATION ---
BASE_URL = "https://forum.obsidian.md"
BUCKET_NAME = os.environ.get("GCS_BUCKET_NAME")
MAX_THREADS = int(os.environ.get("MAX_THREADS", "40"))

SEARCH_TERMS = [
    "AI search", "semantic search", "RAG", "contextual search", 
    "search limitations", "can't find notes", "search overload",
    "AI plugin", "chat with notes", "local AI", "private search", 
    "offline AI", "data privacy"
]

USER_AGENTS = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:123.0) Gecko/20100101 Firefox/123.0'
]

def get_headers():
    return {
        'User-Agent': random.choice(USER_AGENTS),
        'Accept': 'application/json'
    }

def clean_text(text):
    if not text: return ""
    text = re.sub(r'<[^>]+>', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def search_forum(term):
    url = f"{BASE_URL}/search/query.json"
    retries = 0
    max_retries = 3
    
    while retries < max_retries:
        try:
            resp = requests.get(url, headers=get_headers(), params={'term': term}, timeout=10)
            if resp.status_code == 200:
                # SAFEGUARD: Ensure we actually get a list back
                return resp.json().get('topics', [])
            elif resp.status_code == 429:
                wait_time = (retries + 1) * 5
                print(f"⚠️ Rate limit on '{term}'. Sleeping {wait_time}s...")
                time.sleep(wait_time)
                retries += 1
            else:
                return []
        except Exception as e:
            print(f"Error searching {term}: {e}")
            return []
    return []

def get_thread_details(thread_id, slug):
    url = f"{BASE_URL}/t/{slug}/{thread_id}.json"
    try:
        time.sleep(random.uniform(1.5, 3.0)) 
        resp = requests.get(url, headers=get_headers(), timeout=10)
        
        if resp.status_code == 200:
            data = resp.json()
            posts = data.get('post_stream', {}).get('posts', [])
            if posts:
                op = posts[0]
                return {
                    'body': clean_text(op.get('cooked', '')),
                    'likes': op.get('yours', 0) or op.get('reaction_users_count', 0)
                }
    except Exception as e:
        print(f"Error fetching thread {thread_id}: {e}")
    return {'body': '[Fetch Failed]', 'likes': 0}

def save_to_gcs(data):
    client = storage.Client()
    bucket = client.bucket(BUCKET_NAME)
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    filename = f"obsidian_forum_scrape_{timestamp}.json"
    blob = bucket.blob(filename)
    blob.upload_from_string(
        data=json.dumps(data, indent=2),
        content_type='application/json'
    )
    return filename

@functions_framework.http
def run_miner(request):
    print(f"Starting Robust Stealth Crawl. Target Bucket: {BUCKET_NAME}")
    unique_threads = {}
    
    try:
        # 1. Search Phase
        for term in SEARCH_TERMS:
            topics = search_forum(term)
            if not topics: continue
            
            for topic in topics:
                # Only keep threads that have an ID and aren't archived
                if topic.get('id') and not topic.get('archived', False):
                    unique_threads[topic['id']] = topic
            time.sleep(random.uniform(2.0, 4.0))

        # 2. Sort & Limit (FIXED: Uses .get() to prevent crashes on missing keys)
        sorted_threads = sorted(
            unique_threads.values(), 
            key=lambda x: x.get('views', 0) + (x.get('posts_count', 0) * 10), 
            reverse=True
        )[:MAX_THREADS]

        # 3. Fetch Details
        final_evidence = []
        print(f"Fetching details for {len(sorted_threads)} threads...")
        
        for i, thread in enumerate(sorted_threads):
            details = get_thread_details(thread['id'], thread['slug'])
            
            final_evidence.append({
                'id': thread['id'],
                'title': thread.get('title', 'Unknown Title'),
                'url': f"{BASE_URL}/t/{thread.get('slug', 'topic')}/{thread['id']}",
                'date': thread.get('created_at', ''),
                'views': thread.get('views', 0),        # Fixed
                'replies': thread.get('posts_count', 0), # Fixed
                'full_text': details['body'],
                'likes': details['likes']
            })
            
            if i % 5 == 0:
                print(f"Processed {i}/{len(sorted_threads)}...")

        # 4. Save Success
        filename = save_to_gcs({"meta": {"status": "complete"}, "threads": final_evidence})
        return f"Success! Saved {len(final_evidence)} threads to {filename}", 200

    except Exception as e:
        # 5. EMERGENCY SAVE
        print(f"🔥 CRITICAL ERROR: {str(e)}. Saving partial data...")
        if 'final_evidence' in locals() and len(final_evidence) > 0:
            filename = save_to_gcs({"meta": {"status": "crashed", "error": str(e)}, "threads": final_evidence})
            return f"Crashed but saved {len(final_evidence)} threads to {filename}. Error: {str(e)}", 200
        return f"Crashed with no data: {str(e)}", 500
